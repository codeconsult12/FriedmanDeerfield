﻿
namespace DemoApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGetData = new System.Windows.Forms.Button();
            this.comboBox_Items = new System.Windows.Forms.ComboBox();
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.comboBox_Variants = new System.Windows.Forms.ComboBox();
            this.label_Items = new System.Windows.Forms.Label();
            this.label_Variants = new System.Windows.Forms.Label();
            this.label_Locations = new System.Windows.Forms.Label();
            this.comboBox_Locations = new System.Windows.Forms.ComboBox();
            this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label_Date = new System.Windows.Forms.Label();
            this.label_Bins = new System.Windows.Forms.Label();
            this.comboBox_Bins = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // btnGetData
            // 
            this.btnGetData.AutoSize = true;
            this.btnGetData.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGetData.Location = new System.Drawing.Point(414, 70);
            this.btnGetData.Name = "btnGetData";
            this.btnGetData.Size = new System.Drawing.Size(100, 35);
            this.btnGetData.TabIndex = 0;
            this.btnGetData.Text = "Get Data";
            this.btnGetData.UseVisualStyleBackColor = true;
            this.btnGetData.Click += new System.EventHandler(this.btnGetData_Click);
            // 
            // comboBox_Items
            // 
            this.comboBox_Items.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_Items.FormattingEnabled = true;
            this.comboBox_Items.Location = new System.Drawing.Point(68, 12);
            this.comboBox_Items.Name = "comboBox_Items";
            this.comboBox_Items.Size = new System.Drawing.Size(150, 29);
            this.comboBox_Items.TabIndex = 1;
            this.comboBox_Items.SelectedIndexChanged += new System.EventHandler(this.comboBox_Items_SelectedIndexChanged);
            // 
            // dataGridView
            // 
            this.dataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.Location = new System.Drawing.Point(5, 142);
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.Size = new System.Drawing.Size(1054, 314);
            this.dataGridView.TabIndex = 2;
            // 
            // comboBox_Variants
            // 
            this.comboBox_Variants.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_Variants.FormattingEnabled = true;
            this.comboBox_Variants.Location = new System.Drawing.Point(364, 12);
            this.comboBox_Variants.Name = "comboBox_Variants";
            this.comboBox_Variants.Size = new System.Drawing.Size(150, 29);
            this.comboBox_Variants.TabIndex = 3;
            this.comboBox_Variants.SelectedIndexChanged += new System.EventHandler(this.comboBox_Variants_SelectedIndexChanged);
            // 
            // label_Items
            // 
            this.label_Items.AutoSize = true;
            this.label_Items.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.label_Items.Location = new System.Drawing.Point(14, 16);
            this.label_Items.Name = "label_Items";
            this.label_Items.Size = new System.Drawing.Size(48, 20);
            this.label_Items.TabIndex = 4;
            this.label_Items.Text = "Items:";
            // 
            // label_Variants
            // 
            this.label_Variants.AutoSize = true;
            this.label_Variants.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.label_Variants.Location = new System.Drawing.Point(294, 16);
            this.label_Variants.Name = "label_Variants";
            this.label_Variants.Size = new System.Drawing.Size(64, 20);
            this.label_Variants.TabIndex = 5;
            this.label_Variants.Text = "Variants:";
            // 
            // label_Locations
            // 
            this.label_Locations.AutoSize = true;
            this.label_Locations.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.label_Locations.Location = new System.Drawing.Point(826, 16);
            this.label_Locations.Name = "label_Locations";
            this.label_Locations.Size = new System.Drawing.Size(75, 20);
            this.label_Locations.TabIndex = 7;
            this.label_Locations.Text = "Locations:";
            this.label_Locations.Visible = false;
            // 
            // comboBox_Locations
            // 
            this.comboBox_Locations.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_Locations.FormattingEnabled = true;
            this.comboBox_Locations.Location = new System.Drawing.Point(907, 12);
            this.comboBox_Locations.Name = "comboBox_Locations";
            this.comboBox_Locations.Size = new System.Drawing.Size(150, 29);
            this.comboBox_Locations.TabIndex = 6;
            this.comboBox_Locations.Visible = false;
            // 
            // dateTimePicker
            // 
            this.dateTimePicker.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.dateTimePicker.Location = new System.Drawing.Point(68, 76);
            this.dateTimePicker.Name = "dateTimePicker";
            this.dateTimePicker.Size = new System.Drawing.Size(275, 29);
            this.dateTimePicker.TabIndex = 8;
            // 
            // label_Date
            // 
            this.label_Date.AutoSize = true;
            this.label_Date.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.label_Date.Location = new System.Drawing.Point(18, 83);
            this.label_Date.Name = "label_Date";
            this.label_Date.Size = new System.Drawing.Size(44, 20);
            this.label_Date.TabIndex = 9;
            this.label_Date.Text = "Date:";
            // 
            // label_Bins
            // 
            this.label_Bins.AutoSize = true;
            this.label_Bins.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.label_Bins.Location = new System.Drawing.Point(862, 63);
            this.label_Bins.Name = "label_Bins";
            this.label_Bins.Size = new System.Drawing.Size(39, 20);
            this.label_Bins.TabIndex = 11;
            this.label_Bins.Text = "Bins:";
            this.label_Bins.Visible = false;
            // 
            // comboBox_Bins
            // 
            this.comboBox_Bins.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_Bins.FormattingEnabled = true;
            this.comboBox_Bins.Location = new System.Drawing.Point(907, 59);
            this.comboBox_Bins.Name = "comboBox_Bins";
            this.comboBox_Bins.Size = new System.Drawing.Size(150, 29);
            this.comboBox_Bins.TabIndex = 10;
            this.comboBox_Bins.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1063, 461);
            this.Controls.Add(this.label_Bins);
            this.Controls.Add(this.comboBox_Bins);
            this.Controls.Add(this.label_Date);
            this.Controls.Add(this.dateTimePicker);
            this.Controls.Add(this.label_Locations);
            this.Controls.Add(this.comboBox_Locations);
            this.Controls.Add(this.label_Variants);
            this.Controls.Add(this.label_Items);
            this.Controls.Add(this.comboBox_Variants);
            this.Controls.Add(this.dataGridView);
            this.Controls.Add(this.comboBox_Items);
            this.Controls.Add(this.btnGetData);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnGetData;
        private System.Windows.Forms.ComboBox comboBox_Items;
        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.ComboBox comboBox_Variants;
        private System.Windows.Forms.Label label_Items;
        private System.Windows.Forms.Label label_Variants;
        private System.Windows.Forms.Label label_Locations;
        private System.Windows.Forms.ComboBox comboBox_Locations;
        private System.Windows.Forms.DateTimePicker dateTimePicker;
        private System.Windows.Forms.Label label_Date;
        private System.Windows.Forms.Label label_Bins;
        private System.Windows.Forms.ComboBox comboBox_Bins;
    }
}

