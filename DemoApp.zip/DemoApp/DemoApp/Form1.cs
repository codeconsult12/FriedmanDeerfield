﻿using NAV;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DemoApp
{
    public partial class Form1 : Form
    {
        NAV.NAV nav = new NAV.NAV(new Uri("https://api.businesscentral.dynamics.com/v2.0/1a9533fb-c524-4eb7-96c8-fbdc362ac6a0/Production/ODataV4/Company('zzz_CRONUS%20USA%2C%20Inc.')/"))
        {
            Credentials = new NetworkCredential("DYN365-ADMIN", "kMLYu2C64oLch3JkvYqzyhvfIfLgOtpd5buBj36L6k4=")
        };


        //Locations[]           locations;
        ItemsPage32[]           itemsPage32;
        ItemBinContents[]       itemBinContents;
        ItemBinContents[]       itemBinContentsFiltered;
        ItemVariantsPage5401[]  itemVariantsPage5401;

        public Form1()
        {
            InitializeComponent();
        }



        private void Form1_Load(object sender, EventArgs e)
        {
            //locations             = nav.Locations.ToArray();
            itemsPage32             = nav.ItemsPage32.ToArray();
            itemBinContents         = nav.ItemBinContents.ToArray();
            itemVariantsPage5401    = nav.ItemVariantsPage5401.ToArray();


            comboBox_Items.DataSource           = itemsPage32;
            comboBox_Items.DisplayMember        = "No";
            comboBox_Items.ValueMember          = "No";


            //comboBox_Locations.DataSource       = locations;
            //comboBox_Locations.DisplayMember    = "CODE";
            //comboBox_Locations.ValueMember      = "CODE";

            dateTimePicker.Value = new DateTime(2020, 10, 9);
        }


        private void btnGetData_Click(object sender, EventArgs e)
        {
            try
            {
                //var nav = new NAV.NAV(new Uri("https://api.businesscentral.dynamics.com/v2.0/1a9533fb-c524-4eb7-96c8-fbdc362ac6a0/Production/ODataV4/Company('zzz_CRONUS%20USA%2C%20Inc.')/"))
                //{
                //    Credentials = new NetworkCredential("DYN365-ADMIN", "kMLYu2C64oLch3JkvYqzyhvfIfLgOtpd5buBj36L6k4=")
                //};

                var itemCode        = comboBox_Items.SelectedValue.ToStringSafe();          //"1003";
                var variantCode     = comboBox_Variants.SelectedValue.ToStringSafe();       //"LARGE";
                //var locationCode  = comboBox_Locations.SelectedValue.ToStringSafe();      //"WEST";
                //var binCode         = comboBox_Bins.SelectedValue.ToStringSafe();
                var datePicker      = dateTimePicker.Value;


                var itemLedgerEntries   = nav.ItemLedgerEntriesPage38.Where(i   =>  i.Item_No       ==  itemCode        &&
                                                                                    i.Variant_Code  ==  variantCode     &&
                                                                                    //i.Location_Code ==  locationCode  &&
                                                                                    i.Posting_Date  >=  datePicker).ToArray();
                var itemLedgerEntriesDT = itemLedgerEntries.ToDataTable();


                var purchDocLines       = nav.purchaseDocumentLines.Where(i     =>  i.number        ==  itemCode        &&
                                                                                    i.variantCode   ==  variantCode     &&
                                                                                    //i.locationCode==  locationCode    &&
                                                                                    //i.binCode       ==  binCode         &&
                                                                                    i.orderDate     >=  datePicker      &&
                                                                                    i.documentType  ==  "Order").ToArray();
                var purchDocLinesDT     = purchDocLines.ToDataTable();


                var salesDocLines       = nav.salesDocumentLines.Where(i        =>  i.number        ==  itemCode        &&
                                                                                    i.variantCode   ==  variantCode     &&
                                                                                    //i.locationCode==  locationCode    &&
                                                                                    //i.binCode       ==  binCode         &&
                                                                                    i.postingDate   >=  datePicker      &&
                                                                                    i.documentType  ==  "Order").ToArray();
                var salesDocLinesDT     = salesDocLines.ToDataTable();
                

                DataTable dt = new DataTable();
                dt.Columns.Add("Date");
                dt.Columns.Add("Doc. Type");
                dt.Columns.Add("Doc. No.");
                dt.Columns.Add("Item No.");
                dt.Columns.Add("Variant");
                dt.Columns.Add("Description");
                dt.Columns.Add("Unit Cost");
                dt.Columns.Add("Qty.");
                dt.Columns.Add("Bin Code");
                dt.Columns.Add("Item Charge");
                dt.Columns.Add("Amount");
                dt.Columns.Add("Location");
                dt.Columns.Add("Running Balance");


                foreach (var bin in itemBinContentsFiltered)
                {
                    dt.Columns.Add(bin.Bin_Code.ToStringSafe());
                }


                foreach (var purchLine in purchDocLines)
                {
                    DataRow dr  = dt.NewRow();
                    
                    dr["Date"]          = purchLine.expectedReceiptDate;
                    dr["Doc. Type"]     = "Purch. Order";
                    dr["Doc. No."]      = purchLine.documentNumber;
                    dr["Item No."]      = purchLine.number;
                    dr["Variant"]       = purchLine.variantCode;
                    dr["Description"]   = purchLine.description;
                    dr["Qty."]          = purchLine.quantity;
                    dr["Location"]      = purchLine.locationCode;
                    dr["Unit Cost"]     = purchLine.unitCost;
                    dr["Amount"]        = purchLine.amount;
                    dr["Item Charge"]   = purchLine.allowItemChargeAssignment;
                    dr["Bin Code"]      = purchLine.binCode;

                    if (purchLine.binCode.ToStringSafe() != string.Empty)
                    {
                        dr[purchLine.binCode.ToStringSafe()]    = purchLine.quantity;
                    }

                    dt.Rows.Add(dr);
                }


                foreach (var salesLine in salesDocLines)
                {
                    DataRow dr  = dt.NewRow();
                    
                    dr["Date"]          = salesLine.plannedShipmentDate;
                    dr["Doc. Type"]     = "Sales Order";
                    dr["Doc. No."]      = salesLine.documentNumber;
                    dr["Item No."]      = salesLine.number;
                    dr["Variant"]       = salesLine.variantCode;
                    dr["Description"]   = salesLine.description;
                    dr["Qty."]          = salesLine.quantity * -1;
                    dr["Location"]      = salesLine.locationCode;
                    dr["Unit Cost"]     = salesLine.unitCost;
                    dr["Amount"]        = salesLine.amount;
                    dr["Item Charge"]   = salesLine.allowItemChargeAssignment;
                    dr["Bin Code"]      = salesLine.binCode;

                    if (salesLine.binCode.ToStringSafe() != string.Empty)
                    {
                        dr[salesLine.binCode.ToStringSafe()] = salesLine.quantity * -1;
                    }

                    dt.Rows.Add(dr);
                }

                
                foreach (var itemLedger in itemLedgerEntries)
                {
                    DataRow dr  = dt.NewRow();
                    
                    dr["Date"]          = itemLedger.Posting_Date;
                    dr["Doc. Type"]     = "Item Ledger";
                    dr["Doc. No."]      = itemLedger.Document_No;
                    dr["Item No."]      = itemLedger.Item_No;
                    dr["Variant"]       = itemLedger.Variant_Code;
                    dr["Description"]   = itemLedger.Description;
                    dr["Qty."]          = itemLedger.Quantity;
                    dr["Location"]      = itemLedger.Location_Code;
                    dr["Unit Cost"]     = itemLedger.Unit_of_Measure_Code;
                    dr["Amount"]        = itemLedger.Cost_Amount_Actual;

                    dt.Rows.Add(dr);
                }


                dataGridView.DataSource = dt;
                dataGridView.AutoResizeRows();
                dataGridView.AutoResizeColumns();
                //dataGridView.AutoSizeRowsMode      = DataGridViewAutoSizeRowsMode.AllCells;
                //dataGridView.AutoSizeColumnsMode   = DataGridViewAutoSizeColumnsMode.AllCells;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void comboBox_Items_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox_Variants.DataSource = null;
            comboBox_Variants.DataSource    = itemVariantsPage5401.Where(i => i.Item_No == comboBox_Items.SelectedValue.ToStringSafe()).ToArray();
            comboBox_Variants.DisplayMember = "CODE";
            comboBox_Variants.ValueMember   = "CODE";
        }


        private void comboBox_Variants_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox_Bins.DataSource = null;
            itemBinContentsFiltered     = itemBinContents.Where(i   =>  i.Item_No       ==  comboBox_Items.SelectedValue.ToStringSafe()     &&
                                                                        i.Variant_Code  ==  comboBox_Variants.SelectedValue.ToStringSafe()).ToArray();
            comboBox_Bins.DataSource    = itemBinContentsFiltered;
            comboBox_Bins.DisplayMember = "Bin_Code";
            comboBox_Bins.ValueMember   = "Bin_Code";
        }
    }
}